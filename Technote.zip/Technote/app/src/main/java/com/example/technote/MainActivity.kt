package com.example.technote

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val saveStudent = findViewById<Button>(R.id.saveStudent)
        val deleteStudent = findViewById<Button>(R.id.deleteStudent)
        val updateStudent = findViewById<Button>(R.id.updateStudent)

        saveStudent.setOnClickListener {
            val student = hashMapOf(
                "studentGPA" to studentGPA.text.toString().toDouble(),
                "studentMajor" to studentMajor.text.toString(),
                "studentGraduationDate" to studentGraduationDate.text.toString(),
                "studentName" to studentName.text.toString()
            )
            db.collection("Student")
                .document(studentName.text.toString())
                .set(student)
        }

        deleteStudent.setOnClickListener {
            db.collection("Student")
                .document(studentName.text.toString()).delete()
        }

        updateStudent.setOnClickListener {
            val studentToUpdate = db.collection("Student")
                .document(studentName.text.toString())

            val studentGPACheck = studentGPA.text.toString()
            val studentMajorCheck = studentMajor.text.toString()
            val studentGraduationCheck = studentGraduationDate.text.toString()
            val studentNameCheck = studentName.text.toString()

            if (studentGPACheck.isNotEmpty()) {
                studentToUpdate
                    .update("studentGPA", studentGPA.text.toString().toDouble())
            }
            if (studentMajorCheck.isNotEmpty()) {
                studentToUpdate
                    .update("studentMajor", studentMajor.text.toString())
            }
            if (studentGraduationCheck.isNotEmpty()) {
                studentToUpdate
                    .update("studentGraduationDate", studentGraduationDate.text.toString())
            }
            if (studentNameCheck.isNotEmpty()) {
                studentToUpdate
                    .update("studentName", studentName.text.toString())
            }
        }
    }
}
